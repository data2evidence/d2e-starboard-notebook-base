# starboard-python
![npm](https://img.shields.io/npm/v/starboard-python)

Plugin that adds Python cell support to Starboard

## License

MPL 2.0
