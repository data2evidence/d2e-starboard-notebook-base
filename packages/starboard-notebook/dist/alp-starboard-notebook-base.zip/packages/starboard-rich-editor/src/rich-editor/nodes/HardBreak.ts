import HardBreak from 'rich-markdown-editor/dist/nodes/HardBreak'

export default class HardBreak_ extends HardBreak {
  get name() {
    return 'hardbreak'
  }
}
