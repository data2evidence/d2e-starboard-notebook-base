/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

// import { FC } from "react";
// import { usePopper } from "react-popper";

// export const Tooltip: FC<{
//   tooltip: string;
//   placement: "top" | "bottom" | "left" | "right";
// }> = ({ children, tooltip, placement }) => {

//   const { styles, attributes } = usePopper(referenceElement, popperElement, {
//     modifiers: [{ name: "arrow", options: { element: arrowElement } }],
//   });

// };
