# starboard-notebook docs

**Update: Consider using the `starboard-wrap` NPM package instead for easier integration.**

## Guides

- [Integrating Starboard Notebook into your website](./integration.md)

- [The Starboard notebook format (`.nb` or `.sbnb`)](./format.md)
