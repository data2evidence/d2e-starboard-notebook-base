# Integrating Starboard Notebook into your website

It is advised to use the `starboard-wrap` NPM package instead which hides some complexities here by providing a custom Starboard notebook custom HTML element.
