# Minting a new release

```shell
npm run bootstrap

npm run build

npm run lerna version

npm run lerna -- publish from-package
```
